NAME = 'add'
AUTHOR = 'Jay Jagpal'
DESCRIPTION = "Add new widgets to the grid"
ICON = 'icons/add.svg'